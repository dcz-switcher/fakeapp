import { Typography } from "mds-react";

function Navbar(){
    return (
        <>
        <div className="navbar">
            <Typography>Navar</Typography>
        </div>
        </>
    )
}

export default Navbar;